
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
from telegram.error import BadRequest
from apscheduler.schedulers.background import BackgroundScheduler
import asyncio
import logging
import json

# TOKENingizni shu yerga yozing
TOKEN = "YOUR_BOT_TOKEN"
CHANNEL_USERNAME = "@your_channel_username"

# Har kuni yuboriladigan so'zlar
with open("words.json", "r", encoding="utf-8") as f:
    WORDS = json.load(f)

logging.basicConfig(level=logging.INFO)

async def is_subscribed(user_id, bot):
    try:
        member = await bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        return member.status in ["member", "administrator", "creator"]
    except BadRequest:
        return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not await is_subscribed(user_id, context.bot):
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("🧷 Obuna bo‘lish", url=f"https://t.me/{CHANNEL_USERNAME.strip('@')}")],
            [InlineKeyboardButton("✅ Tekshirish", callback_data="check_sub")]
        ])
        await update.message.reply_text(
            "📌 Iltimos, kanalga obuna bo‘ling va 'Tekshirish' tugmasini bosing.",
            reply_markup=buttons
        )
        return
    await update.message.reply_text("✅ Obuna tasdiqlandi! Har kuni yangi so‘z yuboriladi.")

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    if query.data == "check_sub":
        if await is_subscribed(user_id, context.bot):
            await query.edit_message_text("✅ Obuna tasdiqlandi! Har kuni sizga so‘z yuboriladi.")
        else:
            await query.edit_message_text("❌ Siz hali obuna bo‘lmagansiz!")

user_list = set()

async def send_daily_word(app):
    for user_id in user_list:
        word_data = WORDS[asyncio.get_event_loop().time_ns() % len(WORDS)]
        text = f"""📚 *Word of the Day*

🔤 *{word_data['word']}*
📖 *Meaning:* {word_data['meaning']}
📝 *Example:* _{word_data['example']}_
"""
        try:
            await app.bot.send_message(chat_id=user_id, text=text, parse_mode="Markdown")
        except Exception as e:
            print(f"Error sending to {user_id}: {e}")

async def register_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_list.add(user_id)

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(CommandHandler("register", register_user))

    scheduler = BackgroundScheduler()
    scheduler.add_job(lambda: asyncio.create_task(send_daily_word(app)), 'interval', hours=24)
    scheduler.start()

    print("✅ Bot ishga tushdi...")
    app.run_polling()

if __name__ == "__main__":
    main()
